// HireLens Mock Data Layer
// Structured to mirror future FastAPI + Supabase backend schemas

export interface Candidate {
  id: string;
  name: string;
  email: string;
  role: string;
  campaign: string;
  campaignId: string;
  stage: 'Applied' | 'Screening' | 'Interview' | 'Offer' | 'Hired' | 'Rejected';
  aiScore: number;
  confidence: 'High' | 'Medium' | 'Low';
  location: string;
  experience: string;
  appliedDate: string;
  tags: string[];
  avatarColor: string;
  initials: string;
  summary: string;
  strengths: { title: string; evidence: string }[];
  risks: { title: string; evidence: string }[];
  skills: { name: string; level: number; evidence: string }[];
  timeline: { date: string; event: string; type: string }[];
  notes: { author: string; date: string; text: string }[];
}

export interface Campaign {
  id: string;
  name: string;
  department: string;
  location: string;
  status: 'Active' | 'Draft' | 'Paused' | 'Closed';
  candidates: number;
  matched: number;
  interviews: number;
  offers: number;
  createdDate: string;
  hiringManager: string;
  description: string;
}

export const campaigns: Campaign[] = [
  { id: 'CMP-001', name: 'Senior Backend Engineer', department: 'Engineering', location: 'Remote (US)', status: 'Active', candidates: 128, matched: 34, interviews: 12, offers: 3, createdDate: '2026-06-12', hiringManager: 'Sarah Kim', description: 'Looking for a senior backend engineer with strong distributed systems experience to join our platform team.' },
  { id: 'CMP-002', name: 'Staff Product Designer', department: 'Design', location: 'San Francisco, CA', status: 'Active', candidates: 86, matched: 21, interviews: 8, offers: 2, createdDate: '2026-06-28', hiringManager: 'Marcus Chen', description: 'Seeking a staff-level product designer to lead design for our AI analysis experience.' },
  { id: 'CMP-003', name: 'Engineering Manager, ML', department: 'Engineering', location: 'New York, NY', status: 'Active', candidates: 64, matched: 15, interviews: 6, offers: 1, createdDate: '2026-07-02', hiringManager: 'Priya Sharma', description: 'Engineering manager for our machine learning infrastructure team of 8 engineers.' },
  { id: 'CMP-004', name: 'Enterprise Account Executive', department: 'Sales', location: 'Remote (US)', status: 'Paused', candidates: 152, matched: 40, interviews: 15, offers: 4, createdDate: '2026-05-20', hiringManager: 'David Rodriguez', description: 'Enterprise AE to own Fortune 500 accounts in the eastern region.' },
  { id: 'CMP-005', name: 'Technical Recruiter', department: 'People', location: 'Austin, TX', status: 'Draft', candidates: 0, matched: 0, interviews: 0, offers: 0, createdDate: '2026-07-18', hiringManager: 'Lena Fischer', description: 'Technical recruiter to scale our engineering hiring across all teams.' },
  { id: 'CMP-006', name: 'DevOps Engineer', department: 'Engineering', location: 'Remote (EU)', status: 'Closed', candidates: 98, matched: 28, interviews: 10, offers: 2, createdDate: '2026-04-08', hiringManager: 'Sarah Kim', description: 'DevOps engineer with Kubernetes and Terraform expertise for our infra team.' },
];

const firstNames = ['Elena', 'James', 'Aisha', 'Michael', 'Sofia', 'Daniel', 'Yuki', 'Carlos', 'Nina', 'Tom', 'Grace', 'Omar', 'Lily', 'Raj', 'Emma', 'Lucas', 'Zara', 'Ben', 'Maya', 'Alex'];
const lastNames = ['Vasquez', 'Chen', 'Okafor', 'Brennan', 'Rossi', 'Park', 'Tanaka', 'Mendez', 'Kovac', 'Wright', 'Liu', 'Hassan', 'Nguyen', 'Patel', 'Schmidt', 'Silva', 'Ahmed', 'Carter', 'Singh', 'Novak'];
const roles = ['Senior Backend Engineer', 'Staff Product Designer', 'Engineering Manager, ML', 'Enterprise Account Executive', 'DevOps Engineer'];
const stages: Candidate['stage'][] = ['Applied', 'Screening', 'Interview', 'Offer', 'Hired', 'Rejected'];
const locations = ['San Francisco, CA', 'New York, NY', 'Austin, TX', 'Seattle, WA', 'Remote (US)', 'Boston, MA', 'Denver, CO', 'Chicago, IL'];
const avatarColors = ['bg-blue-500', 'bg-teal-500', 'bg-violet-500', 'bg-rose-500', 'bg-amber-500', 'bg-emerald-500', 'bg-cyan-600', 'bg-indigo-500'];
const tagPool = ['Python', 'React', 'Kubernetes', 'Leadership', 'ML', 'Figma', 'Sales', 'B2B', 'AWS', 'Go', 'TypeScript', 'Referral', 'Top School', 'FAANG'];

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

const rand = seededRandom(42);

// Role-specific evidence templates so each candidate reads realistically distinct
const roleProfiles: Record<string, {
  summaryFn: (name: string, exp: string) => string;
  strengths: { title: string; evidence: string }[][];
  risks: { title: string; evidence: string }[][];
  skillNames: string[];
}> = {
  'Senior Backend Engineer': {
    summaryFn: (name, exp) => `${name} is a backend engineer with ${exp} of experience across distributed systems and high-throughput services. The resume shows concrete scale metrics, explicit trade-off reasoning, and consistent ownership of production infrastructure. Evidence quality is high: claims are specific and independently verifiable.`,
    strengths: [
      [
        { title: 'Distributed systems depth', evidence: 'Designed an event pipeline handling 2M events/min, with documented Kafka vs Kinesis trade-off analysis and failure-mode planning.' },
        { title: 'Measurable cost impact', evidence: 'Reduced infrastructure spend 34% and improved p99 latency from 800ms to 120ms; methodology described in detail.' },
        { title: 'Production ownership', evidence: 'On-call lead for a tier-1 service with 99.99% SLA across 6 quarters; wrote the team runbook.' },
      ],
      [
        { title: 'API platform experience', evidence: 'Built and versioned a public REST/gRPC API consumed by 200+ enterprise customers; deprecation policy authored by candidate.' },
        { title: 'Database expertise', evidence: 'Led a zero-downtime Postgres-to-CockroachDB migration for a 4TB dataset over 3 months.' },
        { title: 'Mentorship signals', evidence: 'Onboarded 5 junior engineers; two were promoted within 18 months per LinkedIn cross-reference.' },
      ],
    ],
    risks: [
      [
        { title: 'Short recent tenure', evidence: 'Most recent role lasted 11 months with no stated reason — worth a neutral, direct question in the screen.' },
        { title: 'Limited frontend exposure', evidence: 'Role includes occasional React work; resume shows backend-only scope since 2021.' },
      ],
      [
        { title: 'Single-company depth', evidence: '8 of 10 years at one employer; adaptability to a new stack and culture is untested.' },
        { title: 'No on-call mention', evidence: 'Resume omits operational responsibilities; the role requires participating in a 24/7 rotation.' },
      ],
    ],
    skillNames: ['System Design', 'Programming', 'Leadership', 'Communication', 'Domain Fit'],
  },
  'Staff Product Designer': {
    summaryFn: (name, exp) => `${name} is a product designer with ${exp} spanning B2B SaaS and complex data-heavy interfaces. The portfolio demonstrates end-to-end ownership from research through shipped UI, with quantified adoption outcomes. Strong systems-thinking signals; craft quality is evident in case studies.`,
    strengths: [
      [
        { title: 'Design systems leadership', evidence: 'Built a component library adopted by 4 product teams; reduced design-to-dev handoff time by 40% per case study.' },
        { title: 'Research-driven process', evidence: 'Ran 30+ moderated sessions for a dashboard redesign that lifted weekly retention 12%.' },
        { title: 'Data-dense UI craft', evidence: 'Portfolio shows analytics and admin surfaces with clear hierarchy at high information density.' },
      ],
      [
        { title: 'Cross-functional influence', evidence: 'Partnered with PM and engineering on a 9-month replatform; credited by name in the launch retro.' },
        { title: 'Accessibility rigor', evidence: 'Led WCAG 2.1 AA compliance audit; documented annotations shipped with every spec.' },
        { title: 'Storytelling', evidence: 'Conference talk on evidence-based design reviews (ConfigEU); clear written artifacts.' },
      ],
    ],
    risks: [
      [
        { title: 'No marketing-site work', evidence: 'All portfolio pieces are product UI; this role includes occasional brand/web work.' },
        { title: 'Team size unclear', evidence: 'Says "led design" on two projects but headcount and reporting lines are not specified.' },
      ],
      [
        { title: 'Agency-heavy background', evidence: 'Most tenure in agencies with 3-6 month engagements; long-horizon product iteration is less proven.' },
        { title: 'Tooling gap', evidence: 'No mention of Figma variables/tokens workflows the team relies on daily.' },
      ],
    ],
    skillNames: ['Product Thinking', 'Visual Craft', 'Research', 'Communication', 'Domain Fit'],
  },
  'Engineering Manager, ML': {
    summaryFn: (name, exp) => `${name} is an engineering leader with ${exp}, most recently managing ML infrastructure teams. The resume balances people leadership (hiring, growth, retention) with credible technical depth in model serving and data pipelines. Evidence suggests a hands-on manager who still reviews design docs.`,
    strengths: [
      [
        { title: 'Team scaling', evidence: 'Grew an ML platform team from 3 to 11 engineers in 18 months with 92% retention; hiring rubric authored by candidate.' },
        { title: 'Delivery track record', evidence: 'Shipped a feature-store migration that cut model deployment time from 2 weeks to 2 days.' },
        { title: 'Technical credibility', evidence: 'Still authors design reviews; holds two patents in low-latency model serving.' },
      ],
      [
        { title: 'Cross-org alignment', evidence: 'Drove a quarterly planning process adopted by 3 sister teams; cited in VP recommendation letter.' },
        { title: 'Incident leadership', evidence: 'Ran postmortem culture; sev-1 count dropped 60% year-over-year under their ownership.' },
        { title: 'Budget ownership', evidence: 'Managed $2.4M annual cloud budget; negotiated committed-use discounts saving 22%.' },
      ],
    ],
    risks: [
      [
        { title: 'IC-to-manager recency', evidence: 'Only 2.5 years of formal management; this role owns 8 engineers and two workstreams.' },
        { title: 'Domain adjacency', evidence: 'ML infra background is strong but recruiting-domain ML (ranking, parsing) is new territory.' },
      ],
      [
        { title: 'No startup experience', evidence: 'Career entirely at 1000+ person companies; comfort with ambiguity is untested.' },
        { title: 'Relocation question', evidence: 'Based in Seattle; role is NYC-hybrid and resume does not state willingness to relocate.' },
      ],
    ],
    skillNames: ['People Leadership', 'ML Systems', 'Execution', 'Communication', 'Domain Fit'],
  },
  'Enterprise Account Executive': {
    summaryFn: (name, exp) => `${name} is an enterprise seller with ${exp} carrying seven-figure quotas in B2B SaaS. The resume quantifies attainment for every year listed and names logos closed. Strong outbound motion; evidence of multi-threaded deals with security and procurement involvement.`,
    strengths: [
      [
        { title: 'Consistent quota attainment', evidence: '112%, 134%, and 121% attainment over the last three fiscal years against a $1.4M quota.' },
        { title: 'Enterprise logo wins', evidence: 'Closed two Fortune 500 accounts including a $480K ACV deal with an 11-month cycle.' },
        { title: 'Multi-threading discipline', evidence: 'Describes engaging security, legal, and CFO stakeholders; MEDDPICC methodology cited with examples.' },
      ],
      [
        { title: 'Pipeline generation', evidence: 'Self-sourced 60% of pipeline via outbound; built a repeatable sequence adopted by the team.' },
        { title: 'Expansion motion', evidence: 'Grew an existing account from $90K to $310K ARR in 14 months through two upsells.' },
        { title: 'Fast ramp', evidence: 'Hit first quota within 4 months at last two companies — strong signal for time-to-productivity.' },
      ],
    ],
    risks: [
      [
        { title: 'Category adjacency', evidence: 'Sold dev-tools and infra; HR-tech buyer personas (CHRO, TA leaders) are new.' },
        { title: 'Average deal size gap', evidence: 'Typical ACV was $80-150K; this territory targets $250K+ enterprise deals.' },
      ],
      [
        { title: 'Tenure pattern', evidence: 'Three companies in five years — each move explained by acquisition or territory change, worth verifying.' },
        { title: 'Team selling untested', evidence: 'Previous roles were solo-territory; this role pairs with an SDR and SE pod.' },
      ],
    ],
    skillNames: ['Closing', 'Prospecting', 'Discovery', 'Communication', 'Domain Fit'],
  },
  'DevOps Engineer': {
    summaryFn: (name, exp) => `${name} is a DevOps engineer with ${exp} focused on Kubernetes platforms and infrastructure-as-code. The resume shows deep automation instincts: everything from cluster provisioning to incident response is codified. Certifications back up hands-on claims.`,
    strengths: [
      [
        { title: 'Kubernetes at scale', evidence: 'Operated 14 production clusters across 3 regions; wrote the cluster-upgrade automation used org-wide.' },
        { title: 'IaC discipline', evidence: '100% of infrastructure in Terraform with drift detection; module registry authored by candidate.' },
        { title: 'Incident response', evidence: 'Cut MTTR from 45 to 12 minutes by building automated runbooks and improving alert routing.' },
      ],
      [
        { title: 'CI/CD ownership', evidence: 'Migrated 80+ services from Jenkins to GitHub Actions; median deploy time dropped 70%.' },
        { title: 'Cost engineering', evidence: 'Spot-instance strategy and rightsizing saved $38K/month, documented in a public blog post.' },
        { title: 'Security posture', evidence: 'Implemented OPA policies and image signing; passed SOC 2 audit with zero infra findings.' },
      ],
    ],
    risks: [
      [
        { title: 'Limited programming depth', evidence: 'Strong in Bash/HCL; role expects Go contributions to internal operators.' },
        { title: 'EU timezone overlap', evidence: 'Based in Lisbon; core team hours are US-East — 4 hours of daily overlap.' },
      ],
      [
        { title: 'Solo-operator history', evidence: 'Was the only DevOps engineer at last two companies; collaboration patterns on a 6-person platform team are unproven.' },
        { title: 'On-prem gap', evidence: 'All experience is cloud-native; some customers require on-prem deployment support.' },
      ],
    ],
    skillNames: ['Kubernetes', 'IaC & Automation', 'Reliability', 'Communication', 'Domain Fit'],
  },
};

export const candidates: Candidate[] = Array.from({ length: 40 }, (_, i) => {
  const fn = firstNames[i % firstNames.length];
  const ln = lastNames[Math.floor(rand() * lastNames.length)];
  const name = `${fn} ${ln}`;
  const roleIdx = Math.floor(rand() * roles.length);
  const role = roles[roleIdx];
  const campaignRef = campaigns[roleIdx];
  const stage = stages[Math.floor(rand() * stages.length)];
  const aiScore = Math.floor(62 + rand() * 36);
  const numTags = 2 + Math.floor(rand() * 3);
  const tags = Array.from({ length: numTags }, () => tagPool[Math.floor(rand() * tagPool.length)]).filter((v, idx, a) => a.indexOf(v) === idx);
  const day = 1 + Math.floor(rand() * 24);
  const profile = roleProfiles[role];
  const variant = i % 2;
  const experience = `${3 + Math.floor(rand() * 12)} years`;

  return {
    id: `CND-${String(1001 + i)}`,
    name,
    email: `${fn.toLowerCase()}.${ln.toLowerCase()}@example.com`,
    role,
    campaign: campaignRef.name,
    campaignId: campaignRef.id,
    stage,
    aiScore,
    confidence: aiScore > 88 ? 'High' : aiScore > 75 ? 'Medium' : 'Low',
    location: locations[Math.floor(rand() * locations.length)],
    experience,
    appliedDate: `2026-07-${String(day).padStart(2, '0')}`,
    tags,
    avatarColor: avatarColors[i % avatarColors.length],
    initials: `${fn[0]}${ln[0]}`,
    summary: profile.summaryFn(name, experience),
    strengths: profile.strengths[variant],
    risks: profile.risks[variant],
    skills: profile.skillNames.map((skillName, si) => ({
      name: skillName,
      level: Math.max(52, Math.min(98, aiScore + [4, 0, -12, -8, 2][si] + (variant === 1 ? -3 : 0))),
      evidence: `Supported by ${2 + ((i + si) % 3)} cited resume passages and cross-referenced role history.`,
    })),
    timeline: [
      { date: `2026-07-${String(day).padStart(2, '0')}`, event: 'Applied via careers page', type: 'applied' },
      { date: `2026-07-${String(Math.min(28, day + 1)).padStart(2, '0')}`, event: 'Resume parsed and analyzed by HireLens AI', type: 'ai' },
      { date: `2026-07-${String(Math.min(28, day + 2)).padStart(2, '0')}`, event: 'Moved to screening by Sarah Kim', type: 'stage' },
      { date: `2026-07-${String(Math.min(28, day + 4)).padStart(2, '0')}`, event: 'Screening call scheduled', type: 'interview' },
    ],
    notes: [
      { author: 'Sarah Kim', date: `2026-07-${String(Math.min(28, day + 2)).padStart(2, '0')}`, text: 'Strong technical background. The distributed systems experience matches exactly what the platform team needs. Want to dig into the short tenure at their last company.' },
      { author: 'Marcus Chen', date: `2026-07-${String(Math.min(28, day + 3)).padStart(2, '0')}`, text: 'Portfolio review done — impressive depth. Recommending we fast-track to technical interview.' },
    ],
  };
});

export const activityFeed = [
  { id: 1, actor: 'HireLens AI', action: 'completed analysis for', target: 'Elena Vasquez', time: '12 min ago', type: 'ai' },
  { id: 2, actor: 'Sarah Kim', action: 'moved', target: 'James Chen to Interview', time: '38 min ago', type: 'stage' },
  { id: 3, actor: 'Marcus Chen', action: 'added a note on', target: 'Aisha Okafor', time: '1 hr ago', type: 'note' },
  { id: 4, actor: 'HireLens AI', action: 'flagged a risk for', target: 'Michael Brennan', time: '2 hrs ago', type: 'risk' },
  { id: 5, actor: 'Priya Sharma', action: 'scheduled interview with', target: 'Sofia Rossi', time: '3 hrs ago', type: 'interview' },
  { id: 6, actor: 'David Rodriguez', action: 'sent offer to', target: 'Daniel Park', time: '5 hrs ago', type: 'offer' },
  { id: 7, actor: 'Lena Fischer', action: 'created campaign', target: 'Technical Recruiter', time: '1 day ago', type: 'campaign' },
  { id: 8, actor: 'HireLens AI', action: 'compared 4 candidates in', target: 'Senior Backend Engineer', time: '1 day ago', type: 'ai' },
];

export const interviews = [
  { id: 1, candidate: 'Sofia Rossi', role: 'Staff Product Designer', time: 'Today, 2:00 PM', interviewer: 'Marcus Chen', type: 'Portfolio Review' },
  { id: 2, candidate: 'James Chen', role: 'Senior Backend Engineer', time: 'Today, 4:30 PM', interviewer: 'Sarah Kim', type: 'System Design' },
  { id: 3, candidate: 'Yuki Tanaka', role: 'Engineering Manager, ML', time: 'Tomorrow, 10:00 AM', interviewer: 'Priya Sharma', type: 'Leadership' },
  { id: 4, candidate: 'Nina Kovac', role: 'Senior Backend Engineer', time: 'Tomorrow, 3:00 PM', interviewer: 'Sarah Kim', type: 'Technical Screen' },
];

export const notifications = [
  { id: 1, title: 'AI analysis complete', body: 'Elena Vasquez scored 94 for Senior Backend Engineer', time: '12 min ago', unread: true, type: 'ai' },
  { id: 2, title: 'Interview reminder', body: 'Sofia Rossi portfolio review starts in 45 minutes', time: '30 min ago', unread: true, type: 'interview' },
  { id: 3, title: 'New high-match candidate', body: 'Grace Liu (91) applied to Engineering Manager, ML', time: '2 hrs ago', unread: true, type: 'candidate' },
  { id: 4, title: 'Offer accepted', body: 'Daniel Park accepted the Enterprise AE offer', time: '5 hrs ago', unread: false, type: 'offer' },
  { id: 5, title: 'Weekly digest ready', body: 'Your hiring summary for Jul 14-21 is available', time: '1 day ago', unread: false, type: 'digest' },
];

export const funnelData = [
  { stage: 'Applied', count: 528, percent: 100 },
  { stage: 'AI Screened', count: 342, percent: 65 },
  { stage: 'Recruiter Review', count: 186, percent: 35 },
  { stage: 'Interview', count: 74, percent: 14 },
  { stage: 'Offer', count: 18, percent: 3.4 },
  { stage: 'Hired', count: 12, percent: 2.3 },
];

export const hiringTrend = [
  { month: 'Feb', applications: 289, hires: 6, interviews: 42 },
  { month: 'Mar', applications: 342, hires: 8, interviews: 51 },
  { month: 'Apr', applications: 401, hires: 7, interviews: 58 },
  { month: 'May', applications: 378, hires: 10, interviews: 63 },
  { month: 'Jun', applications: 456, hires: 9, interviews: 71 },
  { month: 'Jul', applications: 528, hires: 12, interviews: 74 },
];

export const departmentStats = [
  { dept: 'Engineering', open: 3, candidates: 290, avgTimeToHire: 21, offerRate: 68 },
  { dept: 'Design', open: 1, candidates: 86, avgTimeToHire: 18, offerRate: 75 },
  { dept: 'Sales', open: 1, candidates: 152, avgTimeToHire: 14, offerRate: 82 },
  { dept: 'People', open: 1, candidates: 0, avgTimeToHire: 0, offerRate: 0 },
];

export const teamMembers = [
  { id: 1, name: 'Sarah Kim', email: 'sarah@acme.com', role: 'Admin', avatar: 'SK', color: 'bg-teal-500', lastActive: 'Now' },
  { id: 2, name: 'Marcus Chen', email: 'marcus@acme.com', role: 'Recruiter', avatar: 'MC', color: 'bg-blue-500', lastActive: '5 min ago' },
  { id: 3, name: 'Priya Sharma', email: 'priya@acme.com', role: 'Hiring Manager', avatar: 'PS', color: 'bg-violet-500', lastActive: '1 hr ago' },
  { id: 4, name: 'David Rodriguez', email: 'david@acme.com', role: 'Recruiter', avatar: 'DR', color: 'bg-rose-500', lastActive: '3 hrs ago' },
  { id: 5, name: 'Lena Fischer', email: 'lena@acme.com', role: 'Viewer', avatar: 'LF', color: 'bg-amber-500', lastActive: 'Yesterday' },
];

export const apiKeys = [
  { id: 1, name: 'Production API', prefix: 'hl_live_4f8a...c2d1', created: '2026-05-12', lastUsed: '2 min ago', scopes: ['read', 'write'] },
  { id: 2, name: 'Staging Environment', prefix: 'hl_test_9b3e...a7f4', created: '2026-06-01', lastUsed: '1 day ago', scopes: ['read'] },
  { id: 3, name: 'Analytics Export', prefix: 'hl_live_2c6d...e8b9', created: '2026-06-20', lastUsed: 'Never', scopes: ['read'] },
];

export const integrations = [
  { id: 1, name: 'Slack', description: 'Get hiring notifications in your channels', connected: true, icon: 'slack' },
  { id: 2, name: 'Google Calendar', description: 'Sync interview schedules automatically', connected: true, icon: 'calendar' },
  { id: 3, name: 'Greenhouse', description: 'Import candidates from your existing ATS', connected: false, icon: 'greenhouse' },
  { id: 4, name: 'LinkedIn Recruiter', description: 'Source candidates directly from LinkedIn', connected: false, icon: 'linkedin' },
  { id: 5, name: 'Zoom', description: 'Generate meeting links for interviews', connected: true, icon: 'zoom' },
  { id: 6, name: 'Workday', description: 'Sync hires to your HRIS', connected: false, icon: 'workday' },
];

export const auditLogs = [
  { id: 1, actor: 'sarah@acme.com', action: 'candidate.stage_change', target: 'CND-1004', ip: '192.168.4.21', time: '2026-07-25 13:42:18' },
  { id: 2, actor: 'marcus@acme.com', action: 'note.created', target: 'CND-1003', ip: '10.0.2.15', time: '2026-07-25 12:18:03' },
  { id: 3, actor: 'system', action: 'ai.analysis_completed', target: 'CND-1001', ip: '—', time: '2026-07-25 11:55:44' },
  { id: 4, actor: 'priya@acme.com', action: 'interview.scheduled', target: 'CND-1005', ip: '172.16.8.9', time: '2026-07-25 10:31:27' },
  { id: 5, actor: 'sarah@acme.com', action: 'api_key.created', target: 'Analytics Export', ip: '192.168.4.21', time: '2026-06-20 09:12:55' },
];

export const currentUser = {
  name: 'Sarah Kim',
  email: 'sarah@acme.com',
  role: 'Admin',
  avatar: 'SK',
  organization: 'Acme Corp',
  plan: 'Professional',
};
