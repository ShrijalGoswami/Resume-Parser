// HireLens Admin Console — realistic enterprise data layer.
// Style: institutional light theme, teal accent; data is deterministic and distinct (no lorem ipsum).

export interface Org {
  id: string;
  name: string;
  domain: string;
  plan: 'Starter' | 'Growth' | 'Enterprise';
  seats: number;
  seatsUsed: number;
  mrr: number;
  status: 'Active' | 'Trial' | 'Past due' | 'Churned';
  created: string;
  industry: string;
  aiCreditsUsed: number;
  aiCreditsTotal: number;
  storageGb: number;
  owner: string;
  ownerEmail: string;
}

export const orgs: Org[] = [
  { id: 'ORG-2001', name: 'Acme Corp', domain: 'acme.com', plan: 'Enterprise', seats: 50, seatsUsed: 42, mrr: 4950, status: 'Active', created: '2024-11-03', industry: 'Technology', aiCreditsUsed: 68400, aiCreditsTotal: 100000, storageGb: 41.2, owner: 'Sarah Kim', ownerEmail: 'sarah@acme.com' },
  { id: 'ORG-2002', name: 'Northwind Logistics', domain: 'northwind.io', plan: 'Growth', seats: 20, seatsUsed: 17, mrr: 1580, status: 'Active', created: '2025-01-18', industry: 'Logistics', aiCreditsUsed: 21800, aiCreditsTotal: 40000, storageGb: 18.6, owner: 'Tom Eriksen', ownerEmail: 'tom@northwind.io' },
  { id: 'ORG-2003', name: 'Helios Health', domain: 'helioshealth.com', plan: 'Enterprise', seats: 80, seatsUsed: 71, mrr: 7920, status: 'Active', created: '2024-08-22', industry: 'Healthcare', aiCreditsUsed: 91200, aiCreditsTotal: 160000, storageGb: 96.4, owner: 'Dr. Amara Osei', ownerEmail: 'amara@helioshealth.com' },
  { id: 'ORG-2004', name: 'Brightpath Financial', domain: 'brightpath.co', plan: 'Growth', seats: 15, seatsUsed: 15, mrr: 1185, status: 'Past due', created: '2025-03-09', industry: 'Financial services', aiCreditsUsed: 39600, aiCreditsTotal: 40000, storageGb: 12.1, owner: 'Miguel Santana', ownerEmail: 'miguel@brightpath.co' },
  { id: 'ORG-2005', name: 'Vertex Studios', domain: 'vertexstudios.tv', plan: 'Starter', seats: 5, seatsUsed: 3, mrr: 245, status: 'Trial', created: '2026-07-02', industry: 'Media', aiCreditsUsed: 1400, aiCreditsTotal: 5000, storageGb: 1.8, owner: 'Lena Fischer', ownerEmail: 'lena@vertexstudios.tv' },
  { id: 'ORG-2006', name: 'Copperline Manufacturing', domain: 'copperline.com', plan: 'Growth', seats: 25, seatsUsed: 19, mrr: 1975, status: 'Active', created: '2024-12-14', industry: 'Manufacturing', aiCreditsUsed: 15900, aiCreditsTotal: 50000, storageGb: 22.9, owner: 'Ray Donovan', ownerEmail: 'ray@copperline.com' },
  { id: 'ORG-2007', name: 'Bluewater Hospitality', domain: 'bluewater.group', plan: 'Starter', seats: 8, seatsUsed: 6, mrr: 392, status: 'Active', created: '2025-06-27', industry: 'Hospitality', aiCreditsUsed: 4100, aiCreditsTotal: 8000, storageGb: 3.4, owner: 'Priya Nair', ownerEmail: 'priya@bluewater.group' },
  { id: 'ORG-2008', name: 'Quantum Retail Group', domain: 'quantumretail.com', plan: 'Enterprise', seats: 120, seatsUsed: 98, mrr: 11880, status: 'Active', created: '2024-05-30', industry: 'Retail', aiCreditsUsed: 142000, aiCreditsTotal: 240000, storageGb: 138.7, owner: 'Chen Wei', ownerEmail: 'chen@quantumretail.com' },
  { id: 'ORG-2009', name: 'Atlas Education', domain: 'atlasedu.org', plan: 'Starter', seats: 4, seatsUsed: 2, mrr: 196, status: 'Churned', created: '2025-02-11', industry: 'Education', aiCreditsUsed: 0, aiCreditsTotal: 4000, storageGb: 0.9, owner: 'Hannah Doyle', ownerEmail: 'hannah@atlasedu.org' },
  { id: 'ORG-2010', name: 'Ironclad Security', domain: 'ironcladsec.com', plan: 'Growth', seats: 12, seatsUsed: 11, mrr: 948, status: 'Active', created: '2025-05-08', industry: 'Cybersecurity', aiCreditsUsed: 18700, aiCreditsTotal: 24000, storageGb: 9.3, owner: 'Omar Farouk', ownerEmail: 'omar@ironcladsec.com' },
];

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  org: string;
  role: 'Admin' | 'Recruiter' | 'Hiring Manager' | 'Viewer';
  status: 'Active' | 'Invited' | 'Suspended';
  lastActive: string;
  joined: string;
  initials: string;
  color: string;
}

const userSeed: [string, string, string, AdminUser['role'], AdminUser['status'], string, string][] = [
  ['Sarah Kim', 'sarah@acme.com', 'Acme Corp', 'Admin', 'Active', '2 min ago', '2024-11-03'],
  ['Marcus Chen', 'marcus@acme.com', 'Acme Corp', 'Recruiter', 'Active', '18 min ago', '2024-11-05'],
  ['Priya Sharma', 'priya.s@acme.com', 'Acme Corp', 'Hiring Manager', 'Active', '1 hr ago', '2024-12-01'],
  ['Tom Eriksen', 'tom@northwind.io', 'Northwind Logistics', 'Admin', 'Active', '3 hrs ago', '2025-01-18'],
  ['Ingrid Bakker', 'ingrid@northwind.io', 'Northwind Logistics', 'Recruiter', 'Active', 'Yesterday', '2025-01-20'],
  ['Dr. Amara Osei', 'amara@helioshealth.com', 'Helios Health', 'Admin', 'Active', '5 min ago', '2024-08-22'],
  ['David Okafor', 'david@helioshealth.com', 'Helios Health', 'Recruiter', 'Active', '40 min ago', '2024-09-02'],
  ['Julia Mendes', 'julia@helioshealth.com', 'Helios Health', 'Hiring Manager', 'Suspended', '12 days ago', '2024-10-15'],
  ['Miguel Santana', 'miguel@brightpath.co', 'Brightpath Financial', 'Admin', 'Active', '2 days ago', '2025-03-09'],
  ['Lena Fischer', 'lena@vertexstudios.tv', 'Vertex Studios', 'Admin', 'Active', '6 hrs ago', '2026-07-02'],
  ['Ray Donovan', 'ray@copperline.com', 'Copperline Manufacturing', 'Admin', 'Active', 'Yesterday', '2024-12-14'],
  ['Grace Lipa', 'grace@copperline.com', 'Copperline Manufacturing', 'Viewer', 'Invited', '—', '2026-07-20'],
  ['Priya Nair', 'priya@bluewater.group', 'Bluewater Hospitality', 'Admin', 'Active', '4 hrs ago', '2025-06-27'],
  ['Chen Wei', 'chen@quantumretail.com', 'Quantum Retail Group', 'Admin', 'Active', '25 min ago', '2024-05-30'],
  ['Aisha Balogun', 'aisha@quantumretail.com', 'Quantum Retail Group', 'Recruiter', 'Active', '1 hr ago', '2024-06-12'],
  ['Viktor Novak', 'viktor@quantumretail.com', 'Quantum Retail Group', 'Recruiter', 'Active', '2 hrs ago', '2024-07-01'],
  ['Emma Lindqvist', 'emma@quantumretail.com', 'Quantum Retail Group', 'Hiring Manager', 'Active', 'Yesterday', '2024-08-19'],
  ['Omar Farouk', 'omar@ironcladsec.com', 'Ironclad Security', 'Admin', 'Active', '30 min ago', '2025-05-08'],
  ['Nadia Petrova', 'nadia@ironcladsec.com', 'Ironclad Security', 'Recruiter', 'Invited', '—', '2026-07-22'],
  ['Hannah Doyle', 'hannah@atlasedu.org', 'Atlas Education', 'Admin', 'Suspended', '94 days ago', '2025-02-11'],
];

const userColors = ['bg-teal-600', 'bg-indigo-600', 'bg-rose-600', 'bg-amber-600', 'bg-emerald-600', 'bg-sky-600', 'bg-violet-600', 'bg-orange-600'];

export const adminUsers: AdminUser[] = userSeed.map((u, i) => ({
  id: `USR-${3001 + i}`,
  name: u[0], email: u[1], org: u[2], role: u[3], status: u[4], lastActive: u[5], joined: u[6],
  initials: u[0].split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase(),
  color: userColors[i % userColors.length],
}));

export interface Invoice {
  id: string;
  org: string;
  amount: number;
  status: 'Paid' | 'Open' | 'Overdue' | 'Void';
  issued: string;
  due: string;
  plan: string;
  seats: number;
}

export const invoices: Invoice[] = [
  { id: 'INV-2026-0712', org: 'Quantum Retail Group', amount: 11880, status: 'Paid', issued: '2026-07-01', due: '2026-07-15', plan: 'Enterprise', seats: 120 },
  { id: 'INV-2026-0711', org: 'Helios Health', amount: 7920, status: 'Paid', issued: '2026-07-01', due: '2026-07-15', plan: 'Enterprise', seats: 80 },
  { id: 'INV-2026-0710', org: 'Acme Corp', amount: 4950, status: 'Paid', issued: '2026-07-01', due: '2026-07-15', plan: 'Enterprise', seats: 50 },
  { id: 'INV-2026-0709', org: 'Copperline Manufacturing', amount: 1975, status: 'Open', issued: '2026-07-01', due: '2026-07-31', plan: 'Growth', seats: 25 },
  { id: 'INV-2026-0708', org: 'Northwind Logistics', amount: 1580, status: 'Open', issued: '2026-07-01', due: '2026-07-31', plan: 'Growth', seats: 20 },
  { id: 'INV-2026-0707', org: 'Brightpath Financial', amount: 1185, status: 'Overdue', issued: '2026-06-01', due: '2026-06-30', plan: 'Growth', seats: 15 },
  { id: 'INV-2026-0706', org: 'Ironclad Security', amount: 948, status: 'Paid', issued: '2026-07-01', due: '2026-07-15', plan: 'Growth', seats: 12 },
  { id: 'INV-2026-0705', org: 'Bluewater Hospitality', amount: 392, status: 'Paid', issued: '2026-07-01', due: '2026-07-15', plan: 'Starter', seats: 8 },
  { id: 'INV-2026-0704', org: 'Vertex Studios', amount: 245, status: 'Open', issued: '2026-07-02', due: '2026-08-01', plan: 'Starter', seats: 5 },
  { id: 'INV-2026-0603', org: 'Atlas Education', amount: 196, status: 'Void', issued: '2026-06-01', due: '2026-06-30', plan: 'Starter', seats: 4 },
  { id: 'INV-2026-0602', org: 'Acme Corp', amount: 4950, status: 'Paid', issued: '2026-06-01', due: '2026-06-15', plan: 'Enterprise', seats: 50 },
  { id: 'INV-2026-0601', org: 'Quantum Retail Group', amount: 11880, status: 'Paid', issued: '2026-06-01', due: '2026-06-15', plan: 'Enterprise', seats: 120 },
];

export interface Ticket {
  id: string;
  subject: string;
  org: string;
  requester: string;
  priority: 'Urgent' | 'High' | 'Normal' | 'Low';
  status: 'Open' | 'Pending' | 'Resolved' | 'Closed';
  assignee: string;
  updated: string;
  messages: { from: string; internal?: boolean; text: string; time: string }[];
}

export const tickets: Ticket[] = [
  {
    id: 'TKT-4501', subject: 'AI analysis stuck at "parsing" for batch upload', org: 'Quantum Retail Group', requester: 'Aisha Balogun', priority: 'Urgent', status: 'Open', assignee: 'Jonah Reyes', updated: '12 min ago',
    messages: [
      { from: 'Aisha Balogun', text: 'We uploaded 45 resumes for the Store Ops campaign about an hour ago and 12 of them are still showing "parsing". The rest completed in seconds. Can you check?', time: '1 hr ago' },
      { from: 'Jonah Reyes', text: "Thanks Aisha — I can see the batch. Those 12 files are scanned PDFs (image-only), which route through OCR and take longer. They're progressing; ETA ~20 minutes. We'll surface a clearer status for OCR files.", time: '38 min ago' },
      { from: 'Jonah Reyes', internal: true, text: 'Filed PLAT-2211 to add an "OCR queue" badge in the upload UI. Batch is 8/12 complete.', time: '12 min ago' },
    ],
  },
  {
    id: 'TKT-4500', subject: 'Need SSO metadata URL for Okta setup', org: 'Helios Health', requester: 'Dr. Amara Osei', priority: 'High', status: 'Pending', assignee: 'Mira Volkova', updated: '2 hrs ago',
    messages: [
      { from: 'Dr. Amara Osei', text: 'Our IT team is configuring Okta SAML. Where do we find the SP metadata URL and ACS endpoint?', time: '5 hrs ago' },
      { from: 'Mira Volkova', text: 'Hi Amara — Settings → Security → SSO shows both. I\'ve also emailed a step-by-step Okta guide. Could you confirm your Okta org uses OIE (not Classic)?', time: '2 hrs ago' },
    ],
  },
  {
    id: 'TKT-4499', subject: 'Invoice INV-2026-0707 shows overdue despite payment', org: 'Brightpath Financial', requester: 'Miguel Santana', priority: 'High', status: 'Open', assignee: 'Unassigned', updated: '4 hrs ago',
    messages: [
      { from: 'Miguel Santana', text: 'We wired payment for June on the 28th but the portal still shows overdue and our AI credits are throttled. Reference: WIRE-88412.', time: '4 hrs ago' },
    ],
  },
  {
    id: 'TKT-4498', subject: 'Feature request: bulk export interview scorecards', org: 'Acme Corp', requester: 'Marcus Chen', priority: 'Normal', status: 'Open', assignee: 'Jonah Reyes', updated: 'Yesterday',
    messages: [
      { from: 'Marcus Chen', text: 'For our quarterly hiring review we need all scorecards for a campaign as one PDF or CSV. Currently exporting one by one. Possible?', time: 'Yesterday' },
      { from: 'Jonah Reyes', text: 'Great use case — logged as FR-902. Short-term workaround: the campaign analytics CSV includes scorecard averages per candidate.', time: 'Yesterday' },
    ],
  },
  {
    id: 'TKT-4497', subject: 'How do trial limits work for AI credits?', org: 'Vertex Studios', requester: 'Lena Fischer', priority: 'Low', status: 'Resolved', assignee: 'Mira Volkova', updated: '2 days ago',
    messages: [
      { from: 'Lena Fischer', text: 'We\'re on trial — what happens when we hit the 5,000 credit cap?', time: '3 days ago' },
      { from: 'Mira Volkova', text: 'Analyses pause (nothing is lost) and you can either start a paid plan or request a one-time trial extension. I\'ve added 1,000 bonus credits to your account so you can finish your current campaign.', time: '2 days ago' },
      { from: 'Lena Fischer', text: 'Perfect, thank you!', time: '2 days ago' },
    ],
  },
  {
    id: 'TKT-4496', subject: 'GDPR erasure request for former candidate', org: 'Northwind Logistics', requester: 'Tom Eriksen', priority: 'High', status: 'Resolved', assignee: 'Mira Volkova', updated: '3 days ago',
    messages: [
      { from: 'Tom Eriksen', text: 'A candidate emailed requesting full data deletion under GDPR Art. 17. How do we comply?', time: '4 days ago' },
      { from: 'Mira Volkova', text: 'Open the candidate profile → ⋯ menu → "Delete candidate (GDPR)". This purges the resume, analyses, and notes within 30 days including backups, and generates a compliance certificate. Done — certificate sent to your email.', time: '3 days ago' },
    ],
  },
  {
    id: 'TKT-4495', subject: 'Webhook payload missing campaign_id field', org: 'Ironclad Security', requester: 'Omar Farouk', priority: 'Normal', status: 'Closed', assignee: 'Jonah Reyes', updated: '5 days ago',
    messages: [
      { from: 'Omar Farouk', text: 'The candidate.stage_changed webhook payload lacks campaign_id, so we can\'t route events in our ATS sync.', time: '6 days ago' },
      { from: 'Jonah Reyes', text: 'Confirmed — this shipped in v2.4 behind the "webhook v2 payload" flag. I\'ve enabled it for your org; payloads now include campaign_id and stage_from/stage_to.', time: '5 days ago' },
      { from: 'Omar Farouk', text: 'Verified working. Thanks for the fast turnaround.', time: '5 days ago' },
    ],
  },
];

export interface FeatureFlag {
  id: string;
  name: string;
  key: string;
  description: string;
  env: 'Production' | 'Staging' | 'Development';
  enabled: boolean;
  rollout: number;
  updated: string;
  owner: string;
}

export const featureFlags: FeatureFlag[] = [
  { id: 'FLG-01', name: 'Webhook v2 payload', key: 'webhook_v2_payload', description: 'Richer webhook payloads with campaign_id and stage transition fields.', env: 'Production', enabled: true, rollout: 100, updated: '2026-07-20', owner: 'Platform' },
  { id: 'FLG-02', name: 'OCR queue badge', key: 'ocr_queue_badge', description: 'Show a distinct status for image-only PDFs routed through OCR.', env: 'Staging', enabled: true, rollout: 100, updated: '2026-07-24', owner: 'Product' },
  { id: 'FLG-03', name: 'Comparison workspace v2', key: 'compare_v2', description: 'Per-dimension AI reasoning in the candidate comparison view.', env: 'Production', enabled: true, rollout: 75, updated: '2026-07-18', owner: 'AI' },
  { id: 'FLG-04', name: 'Offer management module', key: 'offer_management', description: 'Draft, send, and track offers with approval chains.', env: 'Development', enabled: false, rollout: 0, updated: '2026-07-15', owner: 'Product' },
  { id: 'FLG-05', name: 'Dark theme', key: 'dark_theme', description: 'Full dark palette for the recruiter portal.', env: 'Staging', enabled: true, rollout: 25, updated: '2026-07-22', owner: 'Design' },
  { id: 'FLG-06', name: 'Bulk scorecard export', key: 'bulk_scorecard_export', description: 'One-click PDF/CSV export of all scorecards in a campaign.', env: 'Development', enabled: false, rollout: 0, updated: '2026-07-23', owner: 'Product' },
  { id: 'FLG-07', name: 'EU data residency', key: 'eu_data_residency', description: 'Pin org data to eu-central-1 with regional AI inference.', env: 'Production', enabled: true, rollout: 100, updated: '2026-06-30', owner: 'Platform' },
  { id: 'FLG-08', name: 'Copilot streaming v2', key: 'copilot_streaming_v2', description: 'Token-level streaming with source citations rendered inline.', env: 'Production', enabled: true, rollout: 50, updated: '2026-07-21', owner: 'AI' },
];

export interface AuditEvent {
  id: string;
  actor: string;
  actorEmail: string;
  action: string;
  target: string;
  org: string;
  ip: string;
  time: string;
  severity: 'Info' | 'Warning' | 'Critical';
}

export const auditEvents: AuditEvent[] = [
  { id: 'EVT-9101', actor: 'Sarah Kim', actorEmail: 'sarah@acme.com', action: 'candidate.deleted_gdpr', target: 'CND-0871 (full erasure)', org: 'Acme Corp', ip: '73.162.4.21', time: '2026-07-25 14:02:11', severity: 'Critical' },
  { id: 'EVT-9100', actor: 'System', actorEmail: 'system@hirelens.io', action: 'backup.completed', target: 'Daily snapshot db-prod-07-25', org: '—', ip: '—', time: '2026-07-25 13:00:00', severity: 'Info' },
  { id: 'EVT-9099', actor: 'Omar Farouk', actorEmail: 'omar@ironcladsec.com', action: 'api_key.created', target: 'Key hl_live_...8f2a (read-write)', org: 'Ironclad Security', ip: '196.221.9.87', time: '2026-07-25 12:44:53', severity: 'Warning' },
  { id: 'EVT-9098', actor: 'Jonah Reyes', actorEmail: 'jonah@hirelens.io', action: 'feature_flag.enabled', target: 'webhook_v2_payload → Ironclad Security', org: 'Internal', ip: '10.0.4.12', time: '2026-07-25 11:30:27', severity: 'Info' },
  { id: 'EVT-9097', actor: 'Dr. Amara Osei', actorEmail: 'amara@helioshealth.com', action: 'sso.config_updated', target: 'Okta SAML metadata rotated', org: 'Helios Health', ip: '52.14.88.203', time: '2026-07-25 10:18:44', severity: 'Warning' },
  { id: 'EVT-9096', actor: 'Chen Wei', actorEmail: 'chen@quantumretail.com', action: 'member.role_changed', target: 'Emma Lindqvist: Viewer → Hiring Manager', org: 'Quantum Retail Group', ip: '118.72.44.9', time: '2026-07-25 09:52:08', severity: 'Info' },
  { id: 'EVT-9095', actor: 'System', actorEmail: 'system@hirelens.io', action: 'billing.payment_failed', target: 'INV-2026-0707 · $1,185.00', org: 'Brightpath Financial', ip: '—', time: '2026-07-25 08:00:12', severity: 'Critical' },
  { id: 'EVT-9094', actor: 'Mira Volkova', actorEmail: 'mira@hirelens.io', action: 'credits.granted', target: '+1,000 trial credits', org: 'Vertex Studios', ip: '10.0.4.31', time: '2026-07-24 16:41:35', severity: 'Info' },
  { id: 'EVT-9093', actor: 'Julia Mendes', actorEmail: 'julia@helioshealth.com', action: 'auth.login_blocked', target: '5 failed attempts — account locked 15 min', org: 'Helios Health', ip: '203.0.113.44', time: '2026-07-24 15:22:19', severity: 'Critical' },
  { id: 'EVT-9092', actor: 'Tom Eriksen', actorEmail: 'tom@northwind.io', action: 'export.created', target: 'Campaign analytics CSV (CMP-114)', org: 'Northwind Logistics', ip: '84.211.5.66', time: '2026-07-24 14:09:51', severity: 'Info' },
  { id: 'EVT-9091', actor: 'System', actorEmail: 'system@hirelens.io', action: 'ai.quota_warning', target: 'Brightpath Financial at 99% of credits', org: 'Brightpath Financial', ip: '—', time: '2026-07-24 12:30:00', severity: 'Warning' },
  { id: 'EVT-9090', actor: 'Sarah Kim', actorEmail: 'sarah@acme.com', action: 'member.invited', target: 'lisa.wong@acme.com (Recruiter)', org: 'Acme Corp', ip: '73.162.4.21', time: '2026-07-24 11:15:38', severity: 'Info' },
];

export const systemComponents = [
  { name: 'API Gateway', status: 'Operational', uptime: 99.99, latency: '38 ms' },
  { name: 'PostgreSQL Cluster', status: 'Operational', uptime: 99.98, latency: '4 ms' },
  { name: 'AI Inference (analysis)', status: 'Degraded', uptime: 99.72, latency: '2.9 s' },
  { name: 'Object Storage', status: 'Operational', uptime: 100, latency: '61 ms' },
  { name: 'Job Queue', status: 'Operational', uptime: 99.95, latency: '210 ms' },
  { name: 'Search Index', status: 'Operational', uptime: 99.97, latency: '19 ms' },
] as const;

export const usageTrend = [
  { month: 'Feb', analyses: 8200, apiCalls: 410000, activeUsers: 512 },
  { month: 'Mar', analyses: 9800, apiCalls: 488000, activeUsers: 561 },
  { month: 'Apr', analyses: 11400, apiCalls: 542000, activeUsers: 604 },
  { month: 'May', analyses: 13900, apiCalls: 631000, activeUsers: 668 },
  { month: 'Jun', analyses: 15200, apiCalls: 702000, activeUsers: 721 },
  { month: 'Jul', analyses: 17800, apiCalls: 794000, activeUsers: 783 },
];

export const mrrTrend = [
  { month: 'Feb', mrr: 21400 }, { month: 'Mar', mrr: 24100 }, { month: 'Apr', mrr: 26800 },
  { month: 'May', mrr: 28900 }, { month: 'Jun', mrr: 30200 }, { month: 'Jul', mrr: 31271 },
];

export interface ApiKey {
  id: string;
  name: string;
  prefix: string;
  org: string;
  scope: 'Read-only' | 'Read-write' | 'Admin';
  created: string;
  lastUsed: string;
  status: 'Active' | 'Revoked';
}

export const apiKeys: ApiKey[] = [
  { id: 'KEY-01', name: 'ATS sync production', prefix: 'hl_live_...8f2a', org: 'Ironclad Security', scope: 'Read-write', created: '2026-07-25', lastUsed: '2 min ago', status: 'Active' },
  { id: 'KEY-02', name: 'Analytics pipeline', prefix: 'hl_live_...c31d', org: 'Quantum Retail Group', scope: 'Read-only', created: '2026-05-14', lastUsed: '1 hr ago', status: 'Active' },
  { id: 'KEY-03', name: 'Careers page embed', prefix: 'hl_live_...94e7', org: 'Acme Corp', scope: 'Read-only', created: '2026-03-02', lastUsed: '15 min ago', status: 'Active' },
  { id: 'KEY-04', name: 'HRIS integration', prefix: 'hl_live_...22b8', org: 'Helios Health', scope: 'Read-write', created: '2026-01-19', lastUsed: '3 days ago', status: 'Active' },
  { id: 'KEY-05', name: 'Legacy import script', prefix: 'hl_live_...77aa', org: 'Northwind Logistics', scope: 'Admin', created: '2025-11-30', lastUsed: '61 days ago', status: 'Revoked' },
];

export const integrations = [
  { name: 'Slack', category: 'Notifications', status: 'Connected', desc: 'High-match alerts and interview reminders in channels.', orgs: 6 },
  { name: 'Okta', category: 'SSO', status: 'Connected', desc: 'SAML single sign-on and SCIM provisioning.', orgs: 3 },
  { name: 'Greenhouse', category: 'ATS', status: 'Connected', desc: 'Two-way candidate and stage sync.', orgs: 2 },
  { name: 'Google Calendar', category: 'Scheduling', status: 'Connected', desc: 'Interview scheduling with availability lookup.', orgs: 8 },
  { name: 'Workday', category: 'HRIS', status: 'Available', desc: 'Employee records and offer handoff.', orgs: 0 },
  { name: 'Zoom', category: 'Video', status: 'Connected', desc: 'Auto-generated meeting links for interviews.', orgs: 7 },
  { name: 'DocuSign', category: 'Documents', status: 'Available', desc: 'Offer letter e-signatures.', orgs: 0 },
  { name: 'BambooHR', category: 'HRIS', status: 'Available', desc: 'New-hire onboarding handoff.', orgs: 0 },
] as const;

export const errorLogs = [
  { id: 'ERR-7801', service: 'ai-inference', message: 'OCR timeout after 120s for scanned PDF (14.2 MB)', count: 12, first: '2026-07-25 12:10', last: '2026-07-25 13:55', level: 'Error' },
  { id: 'ERR-7800', service: 'api-gateway', message: 'Rate limit exceeded for key hl_live_...c31d (429)', count: 340, first: '2026-07-25 09:00', last: '2026-07-25 13:58', level: 'Warning' },
  { id: 'ERR-7799', service: 'webhooks', message: 'Delivery failed to https://ats.ironcladsec.com/hooks — connection refused (retrying)', count: 6, first: '2026-07-25 11:20', last: '2026-07-25 13:40', level: 'Error' },
  { id: 'ERR-7798', service: 'billing', message: 'Stripe charge declined: insufficient_funds (cus_QR8842)', count: 2, first: '2026-07-25 08:00', last: '2026-07-25 08:05', level: 'Critical' },
  { id: 'ERR-7797', service: 'search-index', message: 'Reindex lag above threshold: 42s (target < 10s)', count: 1, first: '2026-07-24 22:14', last: '2026-07-24 22:14', level: 'Warning' },
] as const;

export const backups = [
  { id: 'BKP-0725', type: 'Daily snapshot', target: 'db-prod', size: '48.2 GB', started: '2026-07-25 13:00', duration: '11m 32s', status: 'Completed' },
  { id: 'BKP-0724', type: 'Daily snapshot', target: 'db-prod', size: '47.9 GB', started: '2026-07-24 13:00', duration: '11m 08s', status: 'Completed' },
  { id: 'BKP-W29', type: 'Weekly full', target: 'db-prod + object storage', size: '312.4 GB', started: '2026-07-20 02:00', duration: '1h 42m', status: 'Completed' },
  { id: 'BKP-0723', type: 'Daily snapshot', target: 'db-prod', size: '47.5 GB', started: '2026-07-23 13:00', duration: '10m 51s', status: 'Completed' },
  { id: 'BKP-0722', type: 'Daily snapshot', target: 'db-prod', size: '47.1 GB', started: '2026-07-22 13:00', duration: '12m 03s', status: 'Completed' },
] as const;

export const emailTemplates = [
  { id: 'TPL-01', name: 'Interview invitation', subject: 'Interview with {{company}} — {{role}}', updated: '2026-07-18', status: 'Active', opens: '68%' },
  { id: 'TPL-02', name: 'Application received', subject: 'We received your application for {{role}}', updated: '2026-07-10', status: 'Active', opens: '81%' },
  { id: 'TPL-03', name: 'Offer letter', subject: 'Your offer from {{company}}', updated: '2026-06-28', status: 'Active', opens: '96%' },
  { id: 'TPL-04', name: 'Rejection (post-interview)', subject: 'Update on your application to {{company}}', updated: '2026-06-15', status: 'Active', opens: '74%' },
  { id: 'TPL-05', name: 'Trial expiring reminder', subject: 'Your HireLens trial ends in 3 days', updated: '2026-05-30', status: 'Draft', opens: '—' },
] as const;

export const exportJobs = [
  { id: 'EXP-501', name: 'All candidates (Quantum Retail)', format: 'CSV', rows: 4218, requested: '2026-07-25 13:10', by: 'Chen Wei', status: 'Completed', size: '2.1 MB' },
  { id: 'EXP-500', name: 'Audit log Q2', format: 'JSON', rows: 18402, requested: '2026-07-24 09:41', by: 'Mira Volkova', status: 'Completed', size: '14.8 MB' },
  { id: 'EXP-499', name: 'Campaign analytics (Helios)', format: 'CSV', rows: 861, requested: '2026-07-25 14:02', by: 'David Okafor', status: 'Processing', size: '—' },
] as const;

export const importJobs = [
  { id: 'IMP-311', name: 'Greenhouse migration — Quantum Retail', source: 'Greenhouse API', records: 12480, progress: 100, started: '2026-07-19 08:00', status: 'Completed' },
  { id: 'IMP-312', name: 'Legacy resumes — Copperline', source: 'S3 bucket', records: 3400, progress: 100, started: '2026-07-21 10:12', status: 'Completed' },
  { id: 'IMP-313', name: 'Lever export — Bluewater', source: 'CSV upload', records: 920, progress: 64, started: '2026-07-25 13:30', status: 'Processing' },
] as const;
